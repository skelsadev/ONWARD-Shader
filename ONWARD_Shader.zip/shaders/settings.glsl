#ifndef ONWARD_SETTINGS_GLSL
#define ONWARD_SETTINGS_GLSL

#define PIXEL_SIZE 2 // [1 2 3 4 5 6 7 8]
#define POSTERIZATION_LEVELS 16 // [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 22 24 26 28 30 -1]
#define SATURATION 1.0
#define OUTLINE_ENABLED 1 // [0 1]
#define OUTLINE_INTENSITY 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define ITEM_OUTLINES 1 // [0 1]

#define CUSTOM_FOG_DENSITY_OVERWORLD 0.26
#define CUSTOM_FOG_DENSITY_NETHER 10.0
#define CUSTOM_FOG_DENSITY_END 3.0
#define CUSTOM_FOG_DENSITY_WATER 8.0
#define CUSTOM_FOG_DENSITY_POWDER_SNOW 48.0
#define CUSTOM_FOG_DENSITY_LAVA 80.0

#define SHADOWS 1 // [0 1]
#if SHADOWS == 1
#define ENABLE_SHADOWS
#endif

#define SHADOW_QUALITY 1 // [0 1]
#if SHADOW_QUALITY == 0
#define SHADOW_FIXED_RES 512.0
#else
#define SHADOW_FIXED_RES 1024.0
#endif
#define SHADOW_DISTORTION 0.85
#define SHADOW_PIXEL_SNAP 16.0
#define SHADOW_DARKNESS 0.35 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
const float shadowIntervalSize = 7.0; // [1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 11.0 12.0 13.0 14.0 15.0 16.0]
#define SHADOW_POSTERIZE_LEVELS 4
const bool shadowtex0Nearest = true;
const bool shadowtex1Nearest = true;
const bool shadowcolor0Nearest = true;

#define REFLECTIONS_ENABLED 1 // [0 1]
#define REFLECTION_INTENSITY 0.35 // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5]
#define REFLECTION_PIXEL_MULT 2.0 // [2.0 1.0]
#define SSR_STEPS 8 // [2 3 4 5 6 8 10 12 14 16 20 24]

#define WATER_EFFECTS 1 // [0 1]
#define WATER_CAUSTICS 1 // [0 1]
#define WATER_CAUSTICS_INTENSITY 0.4 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

#define GODRAYS 0 // [0 1]
#define GODRAYS_INTENSITY 0.3 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define GODRAYS_SAMPLES 10 // [4 6 8 10 12 16]
#define GODRAYS_PIXEL_MULT 0.5 // [0.5 0.75 1.0 1.25 1.5 2.0 3.0]

#define ATMOSPHERE 1 // [0 1]
#define ATMOSPHERE_INTENSITY 1.0 // [1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]

float AtmosphereIntensityClamped() {
    return clamp(ATMOSPHERE_INTENSITY, 1.0, 2.0);
}

float AtmosphereFogBoost() {
    float t = (AtmosphereIntensityClamped() - 1.0) / 1.0;
    return mix(1.0, 2.5, t);
}

float AtmosphereNebulaBoost() {
    float t = (AtmosphereIntensityClamped() - 1.0) / 1.0;
    return mix(1.0, 2.2, t);
}

float AtmosphereGodrayBoost() {
    float t = (AtmosphereIntensityClamped() - 1.0) / 1.0;
    return mix(1.0, 1.8, t);
}

float AtmosphereFogScale() {
    #if ATMOSPHERE
        float t = clamp(AtmosphereIntensityClamped() - 1.0, 0.0, 1.0);
        return mix(0.82, 1.28, t);
    #else
        return 1.0;
    #endif
}

float AtmosphereHazeScale() {
    #if ATMOSPHERE
        return AtmosphereIntensityClamped();
    #else
        return 0.0;
    #endif
}

float WorldFogDensity() {
    #ifdef NETHER
        return CUSTOM_FOG_DENSITY_NETHER;
    #elif defined(END)
        return CUSTOM_FOG_DENSITY_END * AtmosphereFogBoost();
    #else
        return CUSTOM_FOG_DENSITY_OVERWORLD * AtmosphereFogBoost();
    #endif
}

#define BLOOM 0 // [0 1]
#define BLOOM_INTENSITY 0.6 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

#endif
