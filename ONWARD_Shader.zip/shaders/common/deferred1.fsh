#version 120

#include "/settings.glsl"

uniform int isEyeInWater;
uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D depthtex0;
varying vec2 coord0;

uniform vec3 fogColor;
uniform float far;
uniform float near;
uniform float viewWidth;
uniform float viewHeight;
vec2 view = vec2(viewWidth, viewHeight);

float fogDensity() {
    float density;
    if (isEyeInWater == 2) density = CUSTOM_FOG_DENSITY_LAVA;
    else if (isEyeInWater == 1) density = CUSTOM_FOG_DENSITY_WATER;
    else if (isEyeInWater == 3) density = CUSTOM_FOG_DENSITY_POWDER_SNOW;
    else density = CUSTOM_FOG_DENSITY;
    return density * AtmosphereFogScale();
}

float GetLinearDepth(float depth) {
    return (2.0 * near) / (far + near - depth * (far - near));
}

vec2 darkOutlineOffsets[12] = vec2[12](
    vec2( 1.0, 0.0),
    vec2(-1.0, 1.0),
    vec2( 0.0, 1.0),
    vec2( 1.0, 1.0),
    vec2(-2.0, 2.0),
    vec2(-1.0, 2.0),
    vec2( 0.0, 2.0),
    vec2( 1.0, 2.0),
    vec2( 2.0, 2.0),
    vec2(-2.0, 1.0),
    vec2( 2.0, 1.0),
    vec2( 2.0, 0.0)
);

vec2 detailOutlineOffsets[8] = vec2[8](
    vec2( 1.0, 0.0),
    vec2(-1.0, 0.0),
    vec2( 0.0, 1.0),
    vec2( 0.0,-1.0),
    vec2( 1.0, 1.0),
    vec2(-1.0, 1.0),
    vec2( 1.0,-1.0),
    vec2(-1.0,-1.0)
);

float OutlineLuma(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
}

float GetSilhouetteEdge(float centerLin) {
    vec2 scale = vec2(1.0 / view);
    float outline = 1.0;
    float z = centerLin * far * 2.0;
    for (int i = 0; i < 12; i++) {
        vec2 offset = scale * darkOutlineOffsets[i];
        float sampleZA = texture2D(depthtex0, clamp(coord0 + offset, vec2(0.0), vec2(1.0))).r;
        float sampleZB = texture2D(depthtex0, clamp(coord0 - offset, vec2(0.0), vec2(1.0))).r;
        float sampleZsum = GetLinearDepth(sampleZA) + GetLinearDepth(sampleZB);
        outline *= clamp(1.0 - (z - sampleZsum * far), 0.0, 1.0);
    }
    return clamp(1.0 - outline * 1.1, 0.0, 1.0);
}

float GetDetailEdge(float centerLin, vec3 centerCol) {
    vec2 scale = vec2(0.9 / view);
    float centerLum = OutlineLuma(centerCol);
    vec4 centerData = texture2D(colortex1, coord0);
    float centerMat = floor(centerData.r * 255.0 + 0.5);
    float nearBoost = mix(1.75, 0.68, clamp(centerLin * 8.0, 0.0, 1.0));
    float edge = 0.0;
    for (int i = 0; i < 8; i++) {
        vec2 uv = clamp(coord0 + scale * detailOutlineOffsets[i], vec2(0.0), vec2(1.0));
        vec3 sampleCol = texture2D(colortex0, uv).rgb;
        float sampleLum = OutlineLuma(sampleCol);
        float colorDiff = length(sampleCol - centerCol) * 0.5773503;
        float lumDiff = abs(sampleLum - centerLum);
        float local = max(lumDiff, colorDiff * 0.72);
        float sampleDepth01 = texture2D(depthtex0, uv).r;
        if (sampleDepth01 < 0.999999) {
            float sampleLin = GetLinearDepth(sampleDepth01);
            float depthDiff = abs(sampleLin - centerLin);
            float sameSurface = 1.0 - smoothstep(0.012, 0.065, depthDiff);
            vec4 sampleData = texture2D(colortex1, uv);
            float sampleMat = floor(sampleData.r * 255.0 + 0.5);
            float sameMat = 1.0 - step(0.5, abs(sampleMat - centerMat));
            vec3 centerNorm = centerCol / max(max(centerCol.r, max(centerCol.g, centerCol.b)), 1e-4);
            vec3 sampleNorm = sampleCol / max(max(sampleCol.r, max(sampleCol.g, sampleCol.b)), 1e-4);
            float chromaDiff = length(sampleNorm - centerNorm) * 0.5773503;
            float shadowLike = sameSurface * sameMat * (1.0 - smoothstep(0.10, 0.30, lumDiff)) * (1.0 - smoothstep(0.02, 0.11, chromaDiff));
            float shadowEdgeMask = shadowLike * smoothstep(0.03, 0.16, lumDiff);
            local *= mix(0.78, 1.12, sameSurface);
            local *= nearBoost;
            local *= 1.0 - 0.998 * shadowEdgeMask;
        } else {
            local *= 0.28;
        }
        edge = max(edge, local);
    }
    return smoothstep(0.16, 0.30, edge);
}

void DoDarkOutline(inout vec3 color) {
    float centerDepth01 = texture2D(depthtex0, coord0).r;
    if (centerDepth01 >= 0.999999) return;
    float centerLin = GetLinearDepth(centerDepth01);
    vec3 centerCol = texture2D(colortex0, coord0).rgb;
    float silhouetteEdge = GetSilhouetteEdge(centerLin);
    float detailEdge = 0.0;
#if ITEM_OUTLINES
        detailEdge = GetDetailEdge(centerLin, centerCol);
#endif
    float outlineAmt = max(silhouetteEdge, detailEdge);
    float centerLum = OutlineLuma(centerCol);
    float bright = max(max(centerCol.r, centerCol.g), centerCol.b);
    float emissiveFade = smoothstep(0.58, 1.18, bright + centerLum * 0.35);
    outlineAmt *= OUTLINE_INTENSITY;
    outlineAmt *= 1.18;
    outlineAmt *= (1.0 - emissiveFade * 0.58);
    outlineAmt = clamp(outlineAmt, 0.0, 1.0);
    if (outlineAmt <= 0.0) return;
    float depth = centerLin * fogDensity();
    float fogF = clamp(depth * 1.15, 0.0, 1.0);
    fogF = pow(fogF, 1.25);
    vec3 outlineCol = mix(vec3(0.0), fogColor, fogF * 0.85);
    vec3 colorWithOutlines = mix(color, outlineCol, outlineAmt);
    color = mix(colorWithOutlines, color, fogF);
}

void main() {
    vec4 color = texture2D(colortex0, coord0);
#if OUTLINE_ENABLED
        DoDarkOutline(color.rgb);
#endif
    gl_FragData[0] = color;
}
