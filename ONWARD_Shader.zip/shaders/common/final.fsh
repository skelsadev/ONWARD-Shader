#version 120

#include "/settings.glsl"

uniform sampler2D texture;
uniform sampler2D colortex1;
uniform sampler2D depthtex0;

uniform float frameTimeCounter;
uniform float rainStrength;
uniform float viewWidth;
uniform float viewHeight;
uniform vec3 fogColor;
uniform int isEyeInWater;
uniform int thirdPersonView;
uniform float far;
uniform float near;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform vec3 shadowLightPosition;
uniform int worldTime;
uniform float sunAngle;
uniform ivec2 eyeBrightnessSmooth;

varying vec4 color;
varying vec2 coord0;

vec2 view = vec2(viewWidth, viewHeight);

float clamp01(float v) { return clamp(v, 0.0, 1.0); }
vec2 clamp01v2(vec2 v) { return clamp(v, vec2(0.0), vec2(1.0)); }

float hash12(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

float getDaylightFactor() {
    float wt = float(worldTime);
    float dawn = smoothstep(0.0, 1000.0, wt);
    float dusk = 1.0 - smoothstep(12000.0, 13000.0, wt);
    return clamp(dawn * dusk, 0.0, 1.0);
}

float fogDensity() {
    float density;
    if (isEyeInWater == 2) density = CUSTOM_FOG_DENSITY_LAVA;
    else if (isEyeInWater == 1) density = CUSTOM_FOG_DENSITY_WATER;
    else if (isEyeInWater == 3) density = CUSTOM_FOG_DENSITY_POWDER_SNOW;
    else density = CUSTOM_FOG_DENSITY;
    return density * AtmosphereFogScale();
}

vec4 texture2DPixel(sampler2D tex, vec2 uv) {
    float pix = max(1.0, float(PIXEL_SIZE));
    vec2 v = view / pix;
    return texture2D(tex, floor(uv * v) / v);
}

vec2 PixelateUV(vec2 uv, float mult) {
    float pix = max(1.0, float(PIXEL_SIZE) * mult);
    vec2 v = view / pix;
    return floor(uv * v) / v;
}

vec2 PixelateUVCenter(vec2 uv, float mult) {
    float pix = max(1.0, float(PIXEL_SIZE) * mult);
    vec2 v = view / pix;
    return (floor(uv * v) + 0.5) / v;
}

vec3 SampleReflectionFiltered(vec2 uvCenter, float pixMul) {
    float pix = max(1.0, float(PIXEL_SIZE) * pixMul);
    vec2 cell = pix / view;
    vec2 o = cell * 0.25;
    vec2 u0 = clamp01v2(uvCenter);
    vec3 c = texture2D(texture, u0).rgb;
    c += texture2D(texture, clamp01v2(u0 + vec2(o.x, 0.0))).rgb;
    c += texture2D(texture, clamp01v2(u0 - vec2(o.x, 0.0))).rgb;
    c += texture2D(texture, clamp01v2(u0 + vec2(0.0, o.y))).rgb;
    c += texture2D(texture, clamp01v2(u0 - vec2(0.0, o.y))).rgb;
    return c * 0.2;
}

vec3 generic_desaturate(vec3 c, float factor) {
    vec3 lum = vec3(0.299, 0.587, 0.114);
    vec3 gray = vec3(dot(lum, c));
    return mix(c, gray, factor);
}

void posterize(inout vec3 c) {
    float g = max(c.r, max(c.g, c.b));
    float lower = floor(g * POSTERIZATION_LEVELS) / POSTERIZATION_LEVELS;
    float lowerDiff = abs(g - lower);
    float upper = ceil(g * POSTERIZATION_LEVELS) / POSTERIZATION_LEVELS;
    float upperDiff = abs(upper - g);
    float level = lowerDiff <= upperDiff ? lower : upper;
    c *= level / max(g, 1e-6);
}

float GetLinearDepth(float depth) {
    return (2.0 * near) / (far + near - depth * (far - near));
}

vec3 ReconstructViewPos(vec2 uv, float depth01) {
    vec4 clip = vec4(uv * 2.0 - 1.0, depth01 * 2.0 - 1.0, 1.0);
    vec4 viewPos = gbufferProjectionInverse * clip;
    return viewPos.xyz / max(abs(viewPos.w), 1e-6);
}

vec3 ViewToWorld(vec3 viewPos) {
    return (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
}

vec2 ProjectToScreen(vec3 viewPos) {
    vec4 clip = gbufferProjection * vec4(viewPos, 1.0);
    float w = max(abs(clip.w), 1e-6);
    vec3 ndc = clip.xyz / w;
    return ndc.xy * 0.5 + 0.5;
}

float ScreenDepth(vec2 uv) {
    return texture2D(depthtex0, uv).r;
}

vec3 NormalFromDepthVS(vec2 uv) {
    vec2 texel = 1.0 / view;
    float dC = texture2D(depthtex0, uv).r;
    float dR = texture2D(depthtex0, uv + vec2(texel.x, 0.0)).r;
    float dU = texture2D(depthtex0, uv + vec2(0.0, texel.y)).r;
    vec3 pC = ReconstructViewPos(uv, dC);
    vec3 pR = ReconstructViewPos(uv + vec2(texel.x, 0.0), dR);
    vec3 pU = ReconstructViewPos(uv + vec2(0.0, texel.y), dU);
    vec3 dx = pR - pC;
    vec3 dy = pU - pC;
    vec3 n = normalize(cross(dx, dy));
    if (dC > 0.9999) n = vec3(0.0, 0.0, 1.0);
    return n;
}

float SSAOSample(vec3 pVS,vec3 nVS,vec2 uv,vec2 dir,float radiusPx,float angle) {
    vec2 cs=vec2(cos(angle),sin(angle));
    vec2 rd=vec2(dir.x*cs.x-dir.y*cs.y,dir.x*cs.y+dir.y*cs.x);
    vec2 suv=clamp01v2(uv+rd*(radiusPx/view));
    float ds=texture2D(depthtex0,suv).r;
    if (ds>=0.9999) return 0.0;
    vec3 sVS=ReconstructViewPos(suv,ds);
    vec3 v=sVS-pVS;
    float dist=length(v);
    if (dist<=1e-4) return 0.0;
    vec3 vn=v/dist;
    float plane=max(-dot(v,nVS)+0.0015,0.0);
    float hemi=clamp(dot(-vn,nVS),0.0,1.0);
    float range=1.0-smoothstep(radiusPx*0.020,radiusPx*0.120,dist);
    return plane*hemi*range;
}

float ComputeStableAO(vec2 uv) {
#if WATER_EFFECTS
    if (isEyeInWater==1) return 1.0;
#endif
    float d0=texture2D(depthtex0,uv).r;
    if (d0>=0.9999) return 1.0;
    vec3 pVS=ReconstructViewPos(uv,d0);
    vec3 nVS=NormalFromDepthVS(uv);
    if (dot(nVS,-normalize(pVS))<0.0) nVS=-nVS;
    float viewDist=-pVS.z;
    float radiusPx=mix(2.0,12.0,HBAO_RADIUS);
    radiusPx*=mix(1.0,0.72,smoothstep(6.0,42.0,viewDist));
    radiusPx*=mix(1.0,0.82,smoothstep(0.02,0.12,abs(nVS.z)));
    float angle=hash12(floor(gl_FragCoord.xy/max(SHADOW_PIXEL_SNAP,1.0)))*6.2831853;
    float occ=0.0;
    occ+=SSAOSample(pVS,nVS,uv,vec2( 1.0, 0.0),radiusPx*0.55,angle);
    occ+=SSAOSample(pVS,nVS,uv,vec2(-1.0, 0.0),radiusPx*0.55,angle);
    occ+=SSAOSample(pVS,nVS,uv,vec2( 0.0, 1.0),radiusPx*0.55,angle);
    occ+=SSAOSample(pVS,nVS,uv,vec2( 0.0,-1.0),radiusPx*0.55,angle);
    occ+=SSAOSample(pVS,nVS,uv,vec2( 0.7071, 0.7071),radiusPx,angle);
    occ+=SSAOSample(pVS,nVS,uv,vec2(-0.7071, 0.7071),radiusPx,angle);
    occ+=SSAOSample(pVS,nVS,uv,vec2( 0.7071,-0.7071),radiusPx,angle);
    occ+=SSAOSample(pVS,nVS,uv,vec2(-0.7071,-0.7071),radiusPx,angle);
    occ/=8.0;
    occ*=mix(4.8,7.2,HBAO_INTENSITY);
    occ*=1.0-smoothstep(18.0,56.0,viewDist);
    occ=clamp(occ,0.0,0.92*HBAO_INTENSITY);
    return 1.0-occ;
}

vec3 GetSunDirVS() {
    if (dot(shadowLightPosition,shadowLightPosition)>1e-4&&getDaylightFactor()>0.02) return normalize(shadowLightPosition);
    if (dot(sunPosition,sunPosition)>1e-4) return normalize(sunPosition);
    float t=(float(worldTime)/24000.0)+sunAngle;
    float ang=t*6.2831853;
    vec3 sWS=normalize(vec3(cos(ang),sin(ang),0.25));
    return normalize((gbufferModelView*vec4(sWS,0.0)).xyz);
}

vec3 GetMoonDirVS() {
    if (dot(moonPosition,moonPosition)>1e-4) return normalize(moonPosition);
    return normalize(-GetSunDirVS());
}

float LightOutside(vec2 uv) {
    return clamp(max(max(-uv.x,uv.x-1.0),max(-uv.y,uv.y-1.0)),0.0,3.0);
}

vec2 ResolveDirectionalLightUV(vec3 lightDirVS) {
    return ProjectToScreen(lightDirVS*1000.0);
}

vec3 SampleSkyReflection(vec3 reflDirVS) {
    vec2 skyUV = ProjectToScreen(reflDirVS * 1200.0);
    if (skyUV.x < 0.0 || skyUV.x > 1.0 || skyUV.y < 0.0 || skyUV.y > 1.0) return fogColor;
    float skyDepth = texture2D(depthtex0, skyUV).r;
    if (skyDepth < 0.9995) return fogColor;
    vec3 skyCol = texture2D(texture, skyUV).rgb;
    float lum = dot(skyCol, vec3(0.2126, 0.7152, 0.0722));
    skyCol *= mix(1.0, 1.18, smoothstep(0.35, 1.0, lum));
    return skyCol;
}

float SSRStepCount01() {
    return clamp((float(SSR_STEPS) - 1.0) / 15.0, 0.0, 1.0);
}

float SSRTraceDistance() {
    return mix(10.0, 84.0, SSRStepCount01());
}

float SSRBaseStepSize() {
    return mix(1.45, 0.30, SSRStepCount01());
}

int SSRMaxTraceSteps() {
    return int(mix(6.0, 96.0, SSRStepCount01()));
}

bool SSRTrace(vec3 viewOrigin, vec3 viewDir, int maxSteps, float thickness, float tMax, float baseStepSize, out vec2 hitUV, out float hitFade) {
    hitUV = vec2(-1.0);
    hitFade = 0.0;
    float t = 0.08;
    float tPrev = t;
    vec2 lastUV = vec2(-1.0);
    float lastT = t;
    bool haveLast = false;
    for (int i = 0; i < 96; i++) {
        if (i >= maxSteps) break;
        vec3 pVS = viewOrigin + viewDir * t;
        if (-pVS.z < 0.0 || t > tMax) return false;
        vec2 uv = ProjectToScreen(pVS);
        if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
            if (haveLast) {
                hitUV = lastUV;
                float e = min(min(lastUV.x, 1.0 - lastUV.x), min(lastUV.y, 1.0 - lastUV.y));
                float edge = smoothstep(0.00, 0.10, e);
                vec3 pE = viewOrigin + viewDir * lastT;
                float distFade = clamp(1.0 - (-pE.z) / tMax, 0.0, 1.0);
                hitFade = distFade * edge * (1.0 - float(i) / max(float(maxSteps), 1.0));
                return true;
            }
            return false;
        }
        haveLast = true;
        lastUV = uv;
        lastT = t;
        float d = ScreenDepth(uv);
        if (d >= 1.0) {
            tPrev = t;
            t += baseStepSize;
            continue;
        }
        vec3 sceneVS = ReconstructViewPos(uv, d);
        float rayDepth = -pVS.z;
        float sceneDepth = -sceneVS.z;
        float delta = rayDepth - sceneDepth;
        if (delta > 0.0 && delta < thickness) {
            float a = tPrev;
            float b = t;
            for (int j = 0; j < 5; j++) {
                float m = (a + b) * 0.5;
                vec3 pM = viewOrigin + viewDir * m;
                vec2 uvM = ProjectToScreen(pM);
                if (uvM.x < 0.0 || uvM.x > 1.0 || uvM.y < 0.0 || uvM.y > 1.0) { a = m; continue; }
                float dM = ScreenDepth(uvM);
                if (dM >= 1.0) { a = m; continue; }
                vec3 sM = ReconstructViewPos(uvM, dM);
                float delM = (-pM.z) - (-sM.z);
                if (delM > 0.0) b = m; else a = m;
            }
            vec3 pF = viewOrigin + viewDir * b;
            hitUV = ProjectToScreen(pF);
            float distFade = clamp(1.0 - (-pF.z) / tMax, 0.0, 1.0);
            hitFade = distFade * (1.0 - float(i) / max(float(maxSteps), 1.0));
            return true;
        }
        float stepSize = baseStepSize;
        stepSize *= mix(0.95, 1.35, clamp(rayDepth / max(tMax, 1.0), 0.0, 1.0));
        if (delta > thickness) stepSize = max(stepSize, min(delta * 0.28, 1.10));
        tPrev = t;
        t += stepSize;
    }
    return false;
}

vec3 ScreenSpaceReflection_Generic(vec2 uv, float pixMul) {
    float d0 = ScreenDepth(uv);
    if (d0 > 0.9999) return fogColor;
    vec3 p0VS = ReconstructViewPos(uv, d0);
    vec3 nVS = NormalFromDepthVS(uv);
    vec3 vVS = normalize(-p0VS);
    vec3 rVS = normalize(reflect(vVS, nVS));
    float NoV = clamp(dot(vVS, nVS), 0.0, 1.0);
    vec2 hitUV;
    float fade;
    float startBias = mix(0.045, 0.11, smoothstep(0.30, 0.95, NoV));
    bool hit = SSRTrace(p0VS + nVS * startBias, rVS, SSRMaxTraceSteps(), 0.20, SSRTraceDistance(), SSRBaseStepSize(), hitUV, fade);
    if (!hit) return SampleSkyReflection(rVS);
    if (thirdPersonView == 0) {
        float hitLin = GetLinearDepth(ScreenDepth(hitUV));
        if (hitLin < 0.06) return fogColor;
    }
    float hitLin = GetLinearDepth(ScreenDepth(hitUV));
    float nearHit = 1.0 - smoothstep(0.05, 0.22, hitLin);
    float pixMulLocal = max(1.0, pixMul * mix(0.46, 0.92, 1.0 - nearHit));
    vec2 hitPix = PixelateUVCenter(hitUV, pixMulLocal);
    vec3 refl = SampleReflectionFiltered(hitPix, pixMulLocal);
    vec3 reflRaw = texture2D(texture, clamp01v2(hitUV)).rgb;
    refl = mix(refl, reflRaw, nearHit * 0.35);
    return mix(fogColor, refl, clamp01(fade));
}

vec3 WaterWaveNormalWS(vec3 worldPos) {
    float t = frameTimeCounter;
    float w1 = sin(worldPos.x * 0.45 + t * 0.85) + cos(worldPos.z * 0.40 - t * 0.75);
    float w2 = sin(worldPos.x * 0.55 - t * 0.55 + worldPos.z * 0.30) + cos(worldPos.z * 0.50 + t * 0.60);
    return normalize(vec3(-w1 * 0.35, 16.0, -w2 * 0.35));
}

vec3 ScreenSpaceReflection_Water(vec2 uv, vec3 viewPos, vec3 worldPos, out float confOut) {
    confOut = 0.0;
    vec3 V = normalize(viewPos);
    float surfLin = GetLinearDepth(ScreenDepth(uv));
    vec3 nWSWave = normalize(WaterWaveNormalWS(worldPos));
    float lookDown = clamp(dot(normalize(-viewPos), vec3(0.0, 1.0, 0.0)), 0.0, 1.0);
    float distFlatten = smoothstep(0.04, 0.18, surfLin);
    float angleFlatten = smoothstep(0.30, 0.90, lookDown);
    float flatten = clamp(max(distFlatten, angleFlatten), 0.0, 1.0);
    float waveAmt = mix(0.10, 0.02, flatten);
    vec3 nWS = normalize(mix(vec3(0.0, 1.0, 0.0), nWSWave, waveAmt));
    mat3 mv3 = mat3(gbufferModelView[0].xyz, gbufferModelView[1].xyz, gbufferModelView[2].xyz);
    vec3 nVS = normalize(mv3 * nWS);
    vec3 R = normalize(reflect(V, nVS));
    vec3 sky = SampleSkyReflection(R);
    vec2 hitUV;
    float fade;
    float startBias = mix(0.025, 0.060, smoothstep(0.15, 0.85, lookDown));
    bool hit = SSRTrace(viewPos + nVS * startBias, R, SSRMaxTraceSteps(), 0.28, SSRTraceDistance(), SSRBaseStepSize(), hitUV, fade);
    if (!hit) {
        confOut = 0.0;
        return sky;
    }
    float hitDepth = ScreenDepth(hitUV);
    if (hitDepth >= 0.9997) {
        confOut = 0.0;
        return sky;
    }
    float hitMat = texture2D(colortex1, hitUV).r * 255.0;
    float hitIsWater = step(19.5, hitMat) * step(hitMat, 20.5);
    float hitLin = GetLinearDepth(hitDepth);
    float sameDepth = abs(hitLin - surfLin);
    float uvDist = distance(hitUV, uv);
    float nearSelf = 1.0 - smoothstep(0.010, 0.045, uvDist);
    nearSelf *= 1.0 - smoothstep(0.004, 0.035, sameDepth);
    nearSelf = clamp(nearSelf, 0.0, 1.0);
    if (hitIsWater > 0.5 || nearSelf >= 0.65) {
        confOut = 0.0;
        return sky;
    }
    float pixMulLocal = max(1.0, REFLECTION_PIXEL_MULT * mix(0.72, 1.0, fade));
    vec2 hitPix = PixelateUVCenter(hitUV, pixMulLocal);
    vec3 hitCol = SampleReflectionFiltered(hitPix, pixMulLocal);
    vec3 hitRaw = texture2D(texture, clamp01v2(hitUV)).rgb;
    hitCol = mix(hitCol, hitRaw, 0.30);
    float fres = pow(1.0 - clamp(dot(normalize(-viewPos), nVS), 0.0, 1.0), 3.0);
    float downFade = 1.0 - smoothstep(0.30, 0.86, lookDown);
    confOut = fade * mix(0.55, 1.0, downFade) * mix(0.78, 1.18, fres) * (1.0 - 0.85 * nearSelf);
    confOut = clamp(confOut, 0.0, 1.0);
    return mix(sky, hitCol, confOut);
}

float UnderwaterLightFactor(vec2 uv, vec3 sceneCol) {
    vec4 data = texture2D(colortex1, uv);
    float block = data.g;
    float sky = data.b;
    float day = getDaylightFactor();
    float lum = dot(sceneCol, vec3(0.2126, 0.7152, 0.0722));
    float eyeSky = clamp(float(eyeBrightnessSmooth.y) / 240.0, 0.0, 1.0);
    float local = max(block * 1.35, sky * day * 0.90);
    local = max(local, eyeSky * day * 0.60);
    local = max(local, lum * 0.55);
    return clamp(local, 0.0, 1.0);
}

vec3 UnderwaterCaustics(vec2 uv, float lightFactor) {
    if (isEyeInWater != 1) return vec3(0.0);
    float d = texture2D(depthtex0, uv).r;
    if (d >= 0.9999) return vec3(0.0);
    vec3 pVS = ReconstructViewPos(uv, d);
    vec3 pWS = ViewToWorld(pVS);
    float t = frameTimeCounter;
    float c1 = sin(pWS.x * 2.1 + t * 1.55) * sin(pWS.z * 2.0 + t * 1.35);
    float c2 = cos(pWS.x * 1.4 - t * 1.10) * cos(pWS.z * 1.6 + t * 1.25);
    float c = (c1 + c2) * 0.5;
    c = c * 0.5 + 0.5;
    c = pow(c, 2.0);
    float lin = GetLinearDepth(d);
    float fade = clamp(1.0 - lin * mix(1.45, 0.65, lightFactor), 0.0, 1.0);
    vec3 tint = mix(vec3(0.02, 0.06, 0.10), vec3(0.18, 0.38, 0.56), lightFactor);
    return tint * c * fade * WATER_CAUSTICS_INTENSITY * lightFactor;
}

vec3 ApplyUnderwaterFog(vec3 scene, vec2 uv, float linearDepth, float lightFactor) {
    float mediumDepth = linearDepth * CUSTOM_FOG_DENSITY_WATER * 1.15;
    float fogAmt = 1.0 - exp(-mediumDepth);
    fogAmt = pow(clamp(fogAmt, 0.0, 1.0), 1.22);

    vec3 waterFog = fogColor;
    vec3 fogged = mix(scene, waterFog, fogAmt);

    float luma = dot(fogged, vec3(0.299, 0.587, 0.114));
    fogged = mix(fogged, vec3(luma), fogAmt * 0.02);
    fogged *= mix(1.0, 0.992, fogAmt);

    return fogged;
}

vec3 ApplyMediumFog(vec3 scene, float linearDepth) {
    if (isEyeInWater == 2) {
        float mediumDepth = linearDepth * CUSTOM_FOG_DENSITY_LAVA * 22.0;
        float fogAmt = 1.0 - exp(-mediumDepth);
        fogAmt = clamp(pow(fogAmt, 0.88), 0.0, 1.0);
        fogAmt *= smoothstep(0.002, 0.035, linearDepth);
        return mix(scene, fogColor, fogAmt);
    }

    if (isEyeInWater == 3) {
        float mediumDepth = linearDepth * CUSTOM_FOG_DENSITY_POWDER_SNOW * 14.0;
        float fogAmt = 1.0 - exp(-mediumDepth);
        fogAmt = clamp(pow(fogAmt, 0.90), 0.0, 1.0);
        vec3 snowFog = mix(fogColor, vec3(0.92, 0.94, 0.96), 0.10);
        vec3 fogged = mix(scene, snowFog, fogAmt);
        float luma = dot(fogged, vec3(0.299, 0.587, 0.114));
        fogged = mix(fogged, vec3(luma), fogAmt * 0.06);
        return fogged;
    }

    return scene;
}

vec3 ApplyBloom(vec2 uv, vec3 base) {
#if BLOOM
        vec2 texel = 1.0 / view;
        vec3 acc = vec3(0.0);
        float wsum = 0.0;
        for (int y = -1; y <= 1; y++) {
            for (int x = -1; x <= 1; x++) {
                vec2 suv = PixelateUVCenter(uv + vec2(float(x), float(y)) * texel * 2.0, 1.0);
                vec3 s = texture2D(texture, clamp01v2(suv)).rgb;
                float mx = max(s.r, max(s.g, s.b));
                float mn = min(s.r, min(s.g, s.b));
                float sat = mx - mn;
                vec3 e = max(s - vec3(0.62), vec3(0.0));
                float satW = smoothstep(0.02, 0.10, sat);
                float w = 1.0 / (1.0 + float(x * x + y * y));
                acc += e * mix(0.22, 1.00, satW) * w;
                wsum += w;
            }
        }
        acc /= max(wsum, 1e-5);
        return base + acc * BLOOM_INTENSITY;
#else
        return base;
#endif
}

float SunVisFromDepth(vec2 suv) {
    vec2 uvc=clamp01v2(suv);
    vec2 texel=1.0/view;
    float s=0.0;
    s+=smoothstep(0.9920,1.0,texture2D(depthtex0,uvc).r)*0.24;
    s+=smoothstep(0.9920,1.0,texture2D(depthtex0,clamp01v2(uvc+vec2( texel.x,0.0))).r)*0.12;
    s+=smoothstep(0.9920,1.0,texture2D(depthtex0,clamp01v2(uvc+vec2(-texel.x,0.0))).r)*0.12;
    s+=smoothstep(0.9920,1.0,texture2D(depthtex0,clamp01v2(uvc+vec2(0.0, texel.y))).r)*0.12;
    s+=smoothstep(0.9920,1.0,texture2D(depthtex0,clamp01v2(uvc+vec2(0.0,-texel.y))).r)*0.12;
    s+=smoothstep(0.9920,1.0,texture2D(depthtex0,clamp01v2(uvc+vec2( texel.x, texel.y))).r)*0.07;
    s+=smoothstep(0.9920,1.0,texture2D(depthtex0,clamp01v2(uvc+vec2(-texel.x, texel.y))).r)*0.07;
    s+=smoothstep(0.9920,1.0,texture2D(depthtex0,clamp01v2(uvc+vec2( texel.x,-texel.y))).r)*0.07;
    s+=smoothstep(0.9920,1.0,texture2D(depthtex0,clamp01v2(uvc+vec2(-texel.x,-texel.y))).r)*0.07;
    return s;
}

vec3 GodraysFrom(vec2 uv,vec2 lightUV,vec3 lightDirVS,float intensity) {
    vec2 endUV=lightUV;
    vec2 lightVec=lightUV-uv;
    if (lightUV.x<0.0||lightUV.x>1.0||lightUV.y<0.0||lightUV.y>1.0) {
        float tEnd=1.0;
        if (abs(lightVec.x)>1e-6) {
            if (lightUV.x<0.0) tEnd=min(tEnd,(0.0-uv.x)/lightVec.x);
            else if (lightUV.x>1.0) tEnd=min(tEnd,(1.0-uv.x)/lightVec.x);
        }
        if (abs(lightVec.y)>1e-6) {
            if (lightUV.y<0.0) tEnd=min(tEnd,(0.0-uv.y)/lightVec.y);
            else if (lightUV.y>1.0) tEnd=min(tEnd,(1.0-uv.y)/lightVec.y);
        }
        tEnd=clamp(tEnd,0.0,1.0);
        endUV=uv+lightVec*tEnd;
    }
    vec2 dir=endUV-uv;
    float dist=length(dir);
    if (dist<=1e-6) return vec3(0.0);
    dir/=dist;
    vec2 perp=vec2(-dir.y,dir.x);
    float stepLen=dist/max(1.0,float(GODRAYS_SAMPLES));
    float acc=0.0;
    float wsum=0.0;
    vec2 sampleUV=uv+dir*(0.5*stepLen);
    for (int i=0;i<GODRAYS_SAMPLES;i++) {
        vec2 suv=clamp01v2(sampleUV);
        vec2 micro=perp*(0.6/view);
        float vis=SunVisFromDepth(suv)*0.56;
        vis+=SunVisFromDepth(clamp01v2(suv+micro))*0.22;
        vis+=SunVisFromDepth(clamp01v2(suv-micro))*0.22;
        float t=float(i)/max(1.0,float(GODRAYS_SAMPLES-1));
        float weight=mix(1.25,0.28,t*t);
        acc+=vis*weight;
        wsum+=weight;
        sampleUV+=dir*stepLen;
    }
    acc/=max(1e-4,wsum);
    float shaped=smoothstep(0.16,0.90,acc);
    shaped=pow(shaped,1.35);
    float facing=mix(0.42,1.0,smoothstep(0.10,0.46,-lightDirVS.z));
    float offscreen=LightOutside(lightUV);
    float screenMargin=min(min(lightUV.x,1.0-lightUV.x),min(lightUV.y,1.0-lightUV.y));
    float outsideFade=1.0-smoothstep(0.04,0.88,offscreen);
    float screenEnter=smoothstep(0.01,0.14,screenMargin);
    float edgeFade=mix(outsideFade,outsideFade*screenEnter,step(0.0,screenMargin));
    float distFade=1.0-smoothstep(0.06,1.05,dist);
    return fogColor*(shaped*facing*edgeFade*distFade*intensity);
}

vec3 Godrays(vec2 uv) {
#if GODRAYS
        float dayFactor=getDaylightFactor();
        if (dayFactor<=0.001) return vec3(0.0);
        float skyLight=clamp(float(eyeBrightnessSmooth.y)/240.0,0.0,1.0);
        float caveFade=smoothstep(0.22,0.58,skyLight);
        if (caveFade<=0.001) return vec3(0.0);
        vec3 sourceDir=normalize(GetSunDirVS());
        vec2 sourceUV=ResolveDirectionalLightUV(sourceDir);
        return GodraysFrom(uv,sourceUV,sourceDir,GODRAYS_INTENSITY*dayFactor*caveFade);
#else
        return vec3(0.0);
#endif
}

vec3 ApplyAtmosphere(vec3 scene, float linearDepth, float fogBase) {
    vec3 fogCol = fogColor;
    float fogMix = fogBase;
#if ATMOSPHERE
        float daylight = getDaylightFactor();
        float hazeScale = AtmosphereHazeScale();
        float hazeStrength = daylight * (1.0 - 0.35 * rainStrength) * hazeScale;
        float haze = (1.0 - exp(-pow(linearDepth, 1.8) * 2.2)) * (0.24 * hazeScale);
        haze *= hazeStrength;
        fogMix = clamp(fogBase + haze, 0.0, 1.0);
        fogCol = mix(fogCol, vec3(1.0), 0.08 * hazeStrength);
#endif
    return mix(scene, fogCol, fogMix);
}

void main() {
    vec2 uv = coord0;
    if (WATER_EFFECTS == 1 && isEyeInWater == 1) {
        float wob = (sin((uv.x * 64.0) + frameTimeCounter * 1.8) + cos((uv.y * 64.0) + frameTimeCounter * 1.4)) * 0.0015;
        uv += vec2(wob, -wob);
        uv = PixelateUV(uv, 1.0);
    }
    vec4 outCol = color * texture2DPixel(texture, uv);
    float depth01 = texture2D(depthtex0, uv).r;
    float linearDepth = GetLinearDepth(depth01);
    float mat = texture2D(colortex1, uv).r * 255.0;
    float isWater = step(19.5, mat) * step(mat, 20.5);
    float isMetal = step(20.5, mat) * step(mat, 21.5);
#if REFLECTIONS_ENABLED
        if (isWater > 0.5 || isMetal > 0.5) {
            vec3 viewPos = ReconstructViewPos(uv, depth01);
            vec3 worldPos = ViewToWorld(viewPos);
            if (isWater > 0.5) {
                vec2 px = 1.0 / view;
                vec3 b = texture2D(texture, uv).rgb;
                b += texture2D(texture, uv + vec2( px.x, 0.0)).rgb;
                b += texture2D(texture, uv + vec2(-px.x, 0.0)).rgb;
                b += texture2D(texture, uv + vec2(0.0,  px.y)).rgb;
                b += texture2D(texture, uv + vec2(0.0, -px.y)).rgb;
                b *= 0.2;
                float daylight = getDaylightFactor();
                float lum = dot(b, vec3(0.2126, 0.7152, 0.0722));
                vec3 neutral = vec3(lum);
                vec3 desired = neutral * vec3(0.74, 1.01, 1.65);
                desired += vec3(0.0, 0.01, 0.03) * daylight;
                float tintAmt = mix(0.22, 0.62, daylight);
                b = mix(b, desired, tintAmt);
                b = mix(neutral, b, mix(1.02, 1.18, daylight));
                b *= mix(0.62, 0.86, daylight);
                outCol.rgb = b;
            }
            vec3 refl = fogColor;
            float waterConf = 1.0;
            if (isWater > 0.5) refl = ScreenSpaceReflection_Water(uv, viewPos, worldPos, waterConf);
            else refl = ScreenSpaceReflection_Generic(uv, REFLECTION_PIXEL_MULT);
            float viewDist = -viewPos.z;
            float fade = 1.0 - smoothstep(128.0, 160.0, viewDist);
            float amt = REFLECTION_INTENSITY * fade * 0.5;
            mat3 mv3 = mat3(gbufferModelView[0].xyz, gbufferModelView[1].xyz, gbufferModelView[2].xyz);
            vec3 flatNVS = normalize(mv3 * vec3(0.0, 1.0, 0.0));
            float waterNoV = clamp(dot(normalize(-viewPos), flatNVS), 0.0, 1.0);
            float waterAngleVis = mix(1.22, 0.78, smoothstep(0.08, 0.84, waterNoV));
            amt *= mix(1.0, 2.15, isWater);
            amt *= mix(1.0, waterAngleVis, isWater);
            float baseLum = dot(outCol.rgb, vec3(0.2126, 0.7152, 0.0722));
            float darkScale = clamp(baseLum * 3.0 + 0.10, 0.0, 1.0);
            amt *= mix(0.34, 1.0, darkScale);
            amt = floor(amt * 16.0 + 0.5) / 16.0;
            amt = clamp(amt, 0.0, 1.0);
            if (isWater > 0.5) outCol.rgb = mix(outCol.rgb, refl, amt * clamp01(waterConf));
            else outCol.rgb = mix(outCol.rgb, refl, amt);
        }
#endif
    if (isEyeInWater == 1) {
        float lightFactor = UnderwaterLightFactor(uv, outCol.rgb);
#if WATER_CAUSTICS
            outCol.rgb += UnderwaterCaustics(uv, lightFactor);
#endif
        outCol.rgb = ApplyUnderwaterFog(outCol.rgb, uv, linearDepth, lightFactor);
    }
    outCol.rgb += Godrays(uv);
    outCol.rgb = ApplyBloom(uv, outCol.rgb);
    outCol.rgb = generic_desaturate(outCol.rgb, 1.0 - SATURATION);
    if (POSTERIZATION_LEVELS > 0) posterize(outCol.rgb);
    float fogBase = clamp(linearDepth * fogDensity(), 0.0, 1.0);
    fogBase = 1.0 - exp(-fogBase * 1.6);
    vec2 fpp = floor(coord0 * view / max(float(PIXEL_SIZE), 1.0));
    fogBase = clamp(fogBase + (hash12(fpp) - 0.5) * 0.015, 0.0, 1.0);

    if (isEyeInWater == 2 || isEyeInWater == 3) {
        outCol.rgb = ApplyMediumFog(outCol.rgb, linearDepth);
    } else if (isEyeInWater != 1) {
        outCol.rgb = ApplyAtmosphere(outCol.rgb, linearDepth, fogBase);
    }

    gl_FragColor = outCol;
}
