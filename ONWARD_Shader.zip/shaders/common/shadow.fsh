#version 120

uniform sampler2D texture;

varying vec2 texUV;
varying float alpha;

float hash21(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}

void main() {
    vec4 albedo = texture2D(texture, texUV);
    float a = albedo.a * alpha;
    if (a <= 0.02) discard;
    if (a < 0.98) {
        vec2 cell = floor(texUV * 256.0);
        if (a < hash21(cell)) discard;
    }
    gl_FragData[0] = albedo;
}
