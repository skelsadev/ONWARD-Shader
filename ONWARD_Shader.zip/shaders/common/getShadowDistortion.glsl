float cubeLengthShadow(vec2 v) {
    vec2 t=abs(v*v*v);
    return pow(t.x+t.y,1.0/3.0);
}

float getShadowDistortionFactor(vec2 v) {
    return cubeLengthShadow(v)*SHADOW_DISTORTION+(1.0-SHADOW_DISTORTION);
}

vec3 getShadowDistortion(vec3 shadowClipPos) {
    float factor=getShadowDistortionFactor(shadowClipPos.xy);
    shadowClipPos.xy/=factor;
    shadowClipPos.z*=0.5;
    return shadowClipPos;
}
