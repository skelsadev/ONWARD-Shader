#version 120
#include "/settings.glsl"
/* RENDERTARGETS: 0,1 */
#include "/common/getShadowDistortion.glsl"

uniform sampler2D texture;
uniform sampler2D lightmap;
uniform vec4 entityColor;
uniform float blindness;
uniform vec3 sunPosition;
uniform vec3 shadowLightPosition;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;

#ifdef ENABLE_SHADOWS
uniform sampler2D shadowtex1;
uniform mat4 shadowModelView;
uniform mat4 shadowModelViewInverse;
uniform mat4 shadowProjection;
#endif

varying vec4 color;
varying vec2 coord0;
varying vec2 coord1;
varying vec3 worldNormal;
varying vec3 feetPos;
varying float matId;

float hash12(vec2 p){
    return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453123);
}

#ifdef ENABLE_SHADOWS
vec3 GetShadowLightDir(){
    if(dot(shadowLightPosition,shadowLightPosition)>1e-4) return normalize((gbufferModelViewInverse*vec4(shadowLightPosition,0.0)).xyz);
    return normalize(-(shadowModelViewInverse*vec4(0.0,0.0,-1.0,0.0)).xyz);
}

vec4 GetShadowClipPos(vec3 posFeet){
    return shadowProjection*shadowModelView*vec4(posFeet,1.0);
}

vec3 GetShadowScreenPos(vec4 shadowClip,out bool valid){
    vec3 shadowNdc=shadowClip.xyz/max(abs(shadowClip.w),1e-6);
    vec3 shadowScreen=getShadowDistortion(shadowNdc)*0.5+0.5;
    valid=shadowScreen.x>=0.0&&shadowScreen.x<=1.0&&shadowScreen.y>=0.0&&shadowScreen.y<=1.0&&shadowScreen.z>=0.0&&shadowScreen.z<=1.0;
    return shadowScreen;
}

vec3 GetShadowReceiverOffset(vec3 posFeet,vec3 normal,vec3 lightDir,float viewDist){
    float sunHeight=abs(lightDir.y);
    float ndotl=clamp(abs(dot(normal,lightDir)),0.0,1.0);
    float slope=sqrt(max(0.0,1.0-ndotl*ndotl))/max(ndotl,0.12);
    float wallness=1.0-abs(normal.y);
    float lowSun=1.0-smoothstep(0.18,0.46,sunHeight);
    float distScale=mix(1.0,1.18,smoothstep(10.0,96.0,viewDist));
    float normalBias=(0.023+0.034*slope+0.048*wallness+0.018*lowSun)*distScale;
    float lightBias=(0.009+0.015*wallness+0.006*lowSun)*distScale;
    return normal*normalBias+lightDir*lightBias;
}

vec3 SnapShadowFeetPos(vec3 posFeet){
    #if SHADOW_PIXEL_SNAP > 0
    vec3 worldPos=posFeet+cameraPosition;
    worldPos=(floor(worldPos*SHADOW_PIXEL_SNAP+0.01)+0.5)/SHADOW_PIXEL_SNAP;
    return worldPos-cameraPosition;
    #else
    return posFeet;
    #endif
}

float ShadowDelta(vec3 shadowScreen,vec2 offset){
    float shadowDepth=texture2D(shadowtex1,shadowScreen.xy+offset).r;
    return shadowDepth-shadowScreen.z;
}

float ShadowHardTap(vec3 shadowScreen,vec2 offset){
    return step(0.0,ShadowDelta(shadowScreen,offset));
}

float ShadowEdgeTap(vec3 shadowScreen,vec2 offset,float penumbra){
    return clamp(0.5+0.5*ShadowDelta(shadowScreen,offset)/max(penumbra,1.0e-5),0.0,1.0);
}

float ResolveMiniatureShadow(vec3 shadowScreen){
    float texel=1.0/SHADOW_FIXED_RES;
    float penumbra=max(0.45/SHADOW_FIXED_RES,1.0e-5);

    float h0=ShadowHardTap(shadowScreen,vec2(0.0,0.0));
    float h1=ShadowHardTap(shadowScreen,vec2( texel,0.0));
    float h2=ShadowHardTap(shadowScreen,vec2(-texel,0.0));
    float h3=ShadowHardTap(shadowScreen,vec2(0.0, texel));
    float h4=ShadowHardTap(shadowScreen,vec2(0.0,-texel));

    float minH=min(h0,min(min(h1,h2),min(h3,h4)));
    float maxH=max(h0,max(max(h1,h2),max(h3,h4)));
    float edgeMask=step(0.5,maxH-minH);

    float s=0.0;
    float w=0.0;
    s+=ShadowEdgeTap(shadowScreen,vec2(0.0,0.0),penumbra)*4.0; w+=4.0;
    s+=ShadowEdgeTap(shadowScreen,vec2( texel,0.0),penumbra); w+=1.0;
    s+=ShadowEdgeTap(shadowScreen,vec2(-texel,0.0),penumbra); w+=1.0;
    s+=ShadowEdgeTap(shadowScreen,vec2(0.0, texel),penumbra); w+=1.0;
    s+=ShadowEdgeTap(shadowScreen,vec2(0.0,-texel),penumbra); w+=1.0;
    float soft=s/max(w,1.0e-5);

    return mix(h0,soft,edgeMask*0.70);
}

float StableShadowVisibility(vec3 posFeet,vec3 normal,vec3 lightDir){
    float sunHeight=abs(lightDir.y);
    float viewDist=length(posFeet);
    float wallness=1.0-abs(normal.y);
    float ndotl=clamp(abs(dot(normal,lightDir)),0.0,1.0);
    float slope=sqrt(max(0.0,1.0-ndotl*ndotl))/max(ndotl,0.12);

    vec3 shadowFeetPos=SnapShadowFeetPos(posFeet);
    vec4 shadowClip=GetShadowClipPos(shadowFeetPos+GetShadowReceiverOffset(shadowFeetPos,normal,lightDir,viewDist));

    float distortionFactor=getShadowDistortionFactor(shadowClip.xy/max(abs(shadowClip.w),1e-6));
    float clipBias=(2.85+2.55*slope+3.10*wallness+0.78*(1.0-smoothstep(0.18,0.44,sunHeight)))*distortionFactor/SHADOW_FIXED_RES;
    shadowClip.z-=clipBias;

    bool valid=false;
    vec3 shadowScreen=GetShadowScreenPos(shadowClip,valid);
    if(!valid) return 1.0;

    float s=ResolveMiniatureShadow(shadowScreen);

    float surfaceAllow=smoothstep(0.62,0.78,abs(normal.y));
    s=mix(1.0,s,surfaceAllow);

    float distFade=1.0-smoothstep(104.0,128.0,viewDist);
    float sunFade=smoothstep(0.04,0.14,sunHeight);
    return mix(1.0,s,distFade*sunFade+(1.0-distFade));
}

float StylizedShadow(float shadowRaw){
    return shadowRaw;
}
#endif

void main(){
    vec4 albedo=texture2D(texture,coord0)*color;
    vec3 light=(1.0-blindness)*texture2D(lightmap,coord1).rgb;
    vec3 lightUnshadowed=light;

#ifdef ENABLE_SHADOWS
    vec3 normal=normalize(worldNormal);
    vec3 lightDir=GetShadowLightDir();
    float shadowRaw=StableShadowVisibility(feetPos,normal,lightDir);
    float shadow=clamp(StylizedShadow(shadowRaw),0.0,1.0);
    float sky=clamp(coord1.t*1.15,0.0,1.0);
    float receive=sky;
    float shadowDarken=mix(1.0-SHADOW_DARKNESS,1.0,shadow);
    light=mix(light,light*shadowDarken,clamp(receive,0.0,1.0));
    float blk=clamp(coord1.s*1.35,0.0,1.0);
    blk=blk*blk;
    vec3 blockPreserve=lightUnshadowed*blk;
    light=max(light,blockPreserve);
#endif

    vec4 col=albedo*vec4(light,1.0);

    #if REFLECTIONS_ENABLED
        float isMetal=step(20.5,matId)*step(matId,21.5);
        if(isMetal>0.5){
            vec3 N=normalize(worldNormal);
            vec3 V=normalize(-feetPos);
            vec3 L=normalize(sunPosition);
            vec3 H=normalize(V+L);
            float ndotl=max(dot(N,L),0.0);
            float ndotv=clamp(dot(N,V),0.0,1.0);
            float spec=pow(max(dot(N,H),0.0),52.0);
            float fres=pow(1.0-ndotv,2.5);
            float glint=spec*mix(0.14,0.30,fres)*smoothstep(0.02,0.18,ndotl);
            glint=floor(glint*8.0+0.5)/8.0;
            col.rgb+=vec3(1.00,0.97,0.90)*glint*0.40;
        }
    #endif

    col.rgb=mix(col.rgb,entityColor.rgb,entityColor.a);
    float fog=clamp((gl_FogFragCoord-gl_Fog.start)*gl_Fog.scale,0.0,0.1);
    fog*=AtmosphereFogScale();
    col.rgb=mix(col.rgb,gl_Fog.color.rgb,fog);
    gl_FragData[0]=col;
    gl_FragData[1]=vec4(matId/255.0,clamp(coord1.s,0.0,1.0),clamp(coord1.t,0.0,1.0),1.0);
}
