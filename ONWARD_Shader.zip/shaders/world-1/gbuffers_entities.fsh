#include "/common/gbuffers_lit_entities.fsh"
