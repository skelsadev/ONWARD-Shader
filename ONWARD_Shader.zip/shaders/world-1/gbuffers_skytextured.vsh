#include "/common/gbuffers_skytextured.vsh"
