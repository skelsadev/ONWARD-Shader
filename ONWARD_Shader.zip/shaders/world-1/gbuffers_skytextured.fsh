#include "/common/gbuffers_skytextured.fsh"
